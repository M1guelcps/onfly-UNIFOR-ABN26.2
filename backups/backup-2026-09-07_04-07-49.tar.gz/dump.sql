--
-- PostgreSQL database cluster dump
--

\restrict MJUcgv24yA2Mp6PdS57VC62yuoBSuthsr8YRYuzddstfklhhQspIuZsd2XCvvcO

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:A6gO4x56flQUzcyv5bt5iA==$48Fdgs6Cf1RszDXGLlpg8rhmQfa6Z7gfeDgTGgInnZU=:05PwQ17EmutBTkZ2UFz1/i7WUyoGZYu1qYuSPOFwXPM=';

--
-- User Configurations
--








\unrestrict MJUcgv24yA2Mp6PdS57VC62yuoBSuthsr8YRYuzddstfklhhQspIuZsd2XCvvcO

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict WaHV8O9qjQjRoOH8thHJiIBNdKKrzHLhMQC2HutGGJJJjKzTwSJns13NNZkyMTe

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict WaHV8O9qjQjRoOH8thHJiIBNdKKrzHLhMQC2HutGGJJJjKzTwSJns13NNZkyMTe

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict kHbjBWpmZ1rHfjMHQcq9Sxqhu36H6X45KVSPWSnevJ7MKpFJKdmymem3HwsfDG0

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict kHbjBWpmZ1rHfjMHQcq9Sxqhu36H6X45KVSPWSnevJ7MKpFJKdmymem3HwsfDG0

--
-- PostgreSQL database cluster dump complete
--

